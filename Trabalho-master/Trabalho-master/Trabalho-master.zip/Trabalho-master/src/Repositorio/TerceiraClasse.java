/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Repositorio;

/**
 *
 * @author ALEX DIAS
 */
public class TerceiraClasse {
    
    private String Nome;
    private String Sobrenome;
    private String TestGit;
    
    public void Cadastrar()
    {
        
    }
    
}
