
package Repositorio;

public class PrimeiraClasse {
    
    public static void main(String [] x){
        
        System.out.println("Repositorio.PrimeiraClasse.main()");
    }
    
}
